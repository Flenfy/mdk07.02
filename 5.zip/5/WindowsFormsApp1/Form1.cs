﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeDataGridViews();
        }

        private void InitializeDataGridViews()
        {
            dataGridViewInput.AllowUserToAddRows = false;
            dataGridViewOutput.AllowUserToAddRows = false;
            dataGridViewInput.RowHeadersVisible = false;
            dataGridViewOutput.RowHeadersVisible = false;
            dataGridViewInput.ColumnHeadersVisible = false;
            dataGridViewOutput.ColumnHeadersVisible = false;
        }

        private int[,] GenerateMatrix(int rows, int cols, int min = -50, int max = 50)
        {
            var rnd = new Random();
            int[,] matrix = new int[rows, cols];
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matrix[i, j] = rnd.Next(min, max + 1);
            return matrix;
        }

        private void DisplayMatrix(DataGridView dgv, int[,] matrix)
        {
            dgv.Rows.Clear();
            dgv.Columns.Clear();
            int rows = matrix.GetLength(0), cols = matrix.GetLength(1);
            for (int j = 0; j < cols; j++) dgv.Columns.Add($"C{j}", "");
            dgv.Rows.Add(rows);
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    dgv[j, i].Value = matrix[i, j];
        }

        private int[,] ReadMatrix(DataGridView dgv)
        {
            int rows = dgv.Rows.Count, cols = dgv.Columns.Count;
            int[,] matrix = new int[rows, cols];
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    if (int.TryParse(dgv[j, i].Value?.ToString() ?? "0", out int val))
                        matrix[i, j] = val;
            return matrix;
        }

        private void btnTask16_Click(object sender, EventArgs e)
        {
            int[,] A = GenerateMatrix(10, 10);
            DisplayMatrix(dataGridViewInput, A);

            int max = A[0, 0], maxI = 0, maxJ = 0;
            for (int i = 0; i < 10; i++)
                for (int j = 0; j < 10; j++)
                    if (A[i, j] > max) { max = A[i, j]; maxI = i; maxJ = j; }

            int[,] result = (int[,])A.Clone();
            for (int j = 0; j < 10; j++) result[maxI, j] = 0;
            for (int i = 0; i < 10; i++) result[i, maxJ] = 0;

            DisplayMatrix(dataGridViewOutput, result);
            labelInfo.Text = $"Максимальный элемент: {max} (строка {maxI + 1}, столбец {maxJ + 1})";
        }

        private void btnTask17_Click(object sender, EventArgs e)
        {
            int[,] R = GenerateMatrix(9, 9);
            DisplayMatrix(dataGridViewInput, R);

            int[,] result = (int[,])R.Clone();
            for (int i = 0; i < 9; i++)
            {
                int min = result[i, 0];
                for (int j = 1; j < 9; j++)
                    if (result[i, j] < min) min = result[i, j];
                result[i, 0] = min;
            }

            DisplayMatrix(dataGridViewOutput, result);
            labelInfo.Text = "Первые элементы строк заменены на минимальные в строке";
        }

        private void btnTask18_Click(object sender, EventArgs e)
        {
            int[,] A = GenerateMatrix(10, 20);
            DisplayMatrix(dataGridViewInput, A);

            int[] N = new int[10];
            for (int i = 0; i < 10; i++)
            {
                int count = 0;
                for (int j = 0; j < 20; j++)
                    if (A[i, j] > 0) count++;
                N[i] = count;
            }

            dataGridViewOutput.Rows.Clear();
            dataGridViewOutput.Columns.Clear();
            dataGridViewOutput.Columns.Add("Counts", "Положительные элементы по строкам");
            dataGridViewOutput.Rows.Add(10);
            for (int i = 0; i < 10; i++)
                dataGridViewOutput[0, i].Value = N[i];

            labelInfo.Text = "Массив N (кол-во положительных элементов по строкам): " + string.Join(", ", N);
        }
        private void btnTask19_Click(object sender, EventArgs e)
        {
            int[,] X = GenerateMatrix(5, 5);
            DisplayMatrix(dataGridViewInput, X);

            int H = 0;
            for (int i = 0; i < 5; i++)
                if (X[i, 4] > 0) H++;

            if (H < 3)
            {
                var positives = new System.Text.StringBuilder("Положительные элементы:\n");
                for (int i = 0; i < 5; i++)
                    for (int j = 0; j < 5; j++)
                        if (X[i, j] > 0) positives.Append($"{X[i, j]} ");
                labelInfo.Text = positives.ToString();
                dataGridViewOutput.DataSource = null;
                dataGridViewOutput.Rows.Clear();
                dataGridViewOutput.Columns.Clear();
            }
            else
            {
                int sum = 0;
                for (int i = 0; i < 5; i++) sum += X[i, i];
                labelInfo.Text = $"Сумма главной диагонали: {sum}";
                dataGridViewOutput.DataSource = null;
                dataGridViewOutput.Rows.Clear();
                dataGridViewOutput.Columns.Clear();
            }
        }

        private void btnTask20_Click(object sender, EventArgs e)
        {
            int[,] A = GenerateMatrix(12, 12);
            DisplayMatrix(dataGridViewInput, A);

            int sum = 0;
            for (int i = 0; i < 12; i++)
                for (int j = i + 1; j < 12; j++)
                    sum += A[i, j];

            labelInfo.Text = $"Сумма элементов над главной диагональю: {sum}";
            dataGridViewOutput.DataSource = null;
            dataGridViewOutput.Rows.Clear();
            dataGridViewOutput.Columns.Clear();
        }
    }
}
