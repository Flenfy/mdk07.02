﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewInput = new System.Windows.Forms.DataGridView();
            this.dataGridViewOutput = new System.Windows.Forms.DataGridView();
            this.labelInfo = new System.Windows.Forms.Label();
            this.btnTask16 = new System.Windows.Forms.Button();
            this.btnTask17 = new System.Windows.Forms.Button();
            this.btnTask18 = new System.Windows.Forms.Button();
            this.btnTask19 = new System.Windows.Forms.Button();
            this.btnTask20 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOutput)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewInput
            // 
            this.dataGridViewInput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewInput.Location = new System.Drawing.Point(12, 29);
            this.dataGridViewInput.Name = "dataGridViewInput";
            this.dataGridViewInput.Size = new System.Drawing.Size(359, 334);
            this.dataGridViewInput.TabIndex = 0;
            // 
            // dataGridViewOutput
            // 
            this.dataGridViewOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOutput.Location = new System.Drawing.Point(429, 29);
            this.dataGridViewOutput.Name = "dataGridViewOutput";
            this.dataGridViewOutput.Size = new System.Drawing.Size(359, 334);
            this.dataGridViewOutput.TabIndex = 1;
            // 
            // labelInfo
            // 
            this.labelInfo.AutoSize = true;
            this.labelInfo.Location = new System.Drawing.Point(372, 380);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(35, 13);
            this.labelInfo.TabIndex = 2;
            this.labelInfo.Text = "label1";
            // 
            // btnTask16
            // 
            this.btnTask16.Location = new System.Drawing.Point(12, 460);
            this.btnTask16.Name = "btnTask16";
            this.btnTask16.Size = new System.Drawing.Size(75, 23);
            this.btnTask16.TabIndex = 3;
            this.btnTask16.Text = "16";
            this.btnTask16.UseVisualStyleBackColor = true;
            this.btnTask16.Click += new System.EventHandler(this.btnTask16_Click);
            // 
            // btnTask17
            // 
            this.btnTask17.Location = new System.Drawing.Point(173, 460);
            this.btnTask17.Name = "btnTask17";
            this.btnTask17.Size = new System.Drawing.Size(75, 23);
            this.btnTask17.TabIndex = 4;
            this.btnTask17.Text = "17";
            this.btnTask17.UseVisualStyleBackColor = true;
            this.btnTask17.Click += new System.EventHandler(this.btnTask17_Click);
            // 
            // btnTask18
            // 
            this.btnTask18.Location = new System.Drawing.Point(357, 460);
            this.btnTask18.Name = "btnTask18";
            this.btnTask18.Size = new System.Drawing.Size(75, 23);
            this.btnTask18.TabIndex = 5;
            this.btnTask18.Text = "18";
            this.btnTask18.UseVisualStyleBackColor = true;
            this.btnTask18.Click += new System.EventHandler(this.btnTask18_Click);
            // 
            // btnTask19
            // 
            this.btnTask19.Location = new System.Drawing.Point(537, 460);
            this.btnTask19.Name = "btnTask19";
            this.btnTask19.Size = new System.Drawing.Size(75, 23);
            this.btnTask19.TabIndex = 6;
            this.btnTask19.Text = "19";
            this.btnTask19.UseVisualStyleBackColor = true;
            this.btnTask19.Click += new System.EventHandler(this.btnTask19_Click);
            // 
            // btnTask20
            // 
            this.btnTask20.Location = new System.Drawing.Point(713, 460);
            this.btnTask20.Name = "btnTask20";
            this.btnTask20.Size = new System.Drawing.Size(75, 23);
            this.btnTask20.TabIndex = 7;
            this.btnTask20.Text = "20";
            this.btnTask20.UseVisualStyleBackColor = true;
            this.btnTask20.Click += new System.EventHandler(this.btnTask20_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 614);
            this.Controls.Add(this.btnTask20);
            this.Controls.Add(this.btnTask19);
            this.Controls.Add(this.btnTask18);
            this.Controls.Add(this.btnTask17);
            this.Controls.Add(this.btnTask16);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.dataGridViewOutput);
            this.Controls.Add(this.dataGridViewInput);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOutput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewInput;
        private System.Windows.Forms.DataGridView dataGridViewOutput;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Button btnTask16;
        private System.Windows.Forms.Button btnTask17;
        private System.Windows.Forms.Button btnTask18;
        private System.Windows.Forms.Button btnTask19;
        private System.Windows.Forms.Button btnTask20;
    }
}

