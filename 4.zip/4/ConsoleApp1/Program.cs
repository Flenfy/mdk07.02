﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] a = new int[20];

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = random.Next(-100, 100);
            }

            Console.WriteLine("Исходный массив:");
            Console.WriteLine(string.Join(", ", a));

            int maxIndex = 0;
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > a[maxIndex])
                {
                    maxIndex = i;
                }
            }
            int temp = a[0];
            a[0] = a[maxIndex];
            a[maxIndex] = temp;

            Console.WriteLine("\nМассив после замены первого элемента на максимальный:");
            Console.WriteLine(string.Join(", ", a));
            Console.ReadLine();
        }
    }
}
