﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 10;
            double[] Z = new double[n];
            double[] D = new double[n];

            for (int idx = 0; idx < n; idx++)
            {
                int i = idx + 1;

                if (i % 2 != 0)
                {
                    Z[idx] = i * i + 1;
                }
                else
                {
                    Z[idx] = 2 * i - 1;
                }
            }
            for (int idx = 0; idx < n; idx++)
            {
                if (Z[idx] < 2.5)
                {
                    D[idx] = 2.5 * Z[idx];
                }
                else
                {
                    D[idx] = Z[idx] / 2.5;
                }
            }


            Console.WriteLine("Результаты вычислений:\n");
            Console.WriteLine($"{"i",-4} {"zi",-12} {"di",-12}");
            Console.WriteLine(new string('-', 28));

            for (int idx = 0; idx < n; idx++)
            {
                int i = idx + 1;
                Console.WriteLine($"{i,-4} {Z[idx],-12:F2} {D[idx],-12:F4}");
            }

            Console.ReadLine();
        }
    }
}
