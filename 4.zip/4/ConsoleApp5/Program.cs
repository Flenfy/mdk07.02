﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int n = 27;
            double[] X = new double[n];
            double[] Y = new double[n];


            for (int i = 0; i < n; i++)
            {
                X[i] = random.NextDouble() * 10 - 5;
            }

            Console.WriteLine("Результаты вычислений:\n");
            Console.WriteLine($"{"№",-4} {"xi",-12} {"yi",-15} {"Доп. вычисление",-20}");
            Console.WriteLine(new string('-', 55));

            for (int i = 0; i < n; i++)
            {
                double xi = X[i];


                Y[i] = 6.85 * xi * xi - 1.52;
                double yi = Y[i];

                string extraCalculation;

                if (yi < 0)
                {

                    double a = xi * xi * xi - 0.62;
                    extraCalculation = $"a = {a:F4}";
                }
                else
                {
                  
                    if (Math.Abs(xi) < 1e-10)
                    {
                        extraCalculation = "b = ∞ (деление на 0)";
                    }
                    else
                    {
                        double b = 1.0 / (xi * xi);
                        extraCalculation = $"b = {b:F4}";
                    }
                }


                Console.WriteLine($"{i + 1,-4} {xi,-12:F4} {yi,-15:F4} {extraCalculation}");
            }

            Console.ReadLine();
        }
    }
}
