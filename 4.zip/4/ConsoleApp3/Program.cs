﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            double[] a = new double[15];

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = random.NextDouble() * 200 - 100;
            }

            Console.WriteLine("Исходный массив:");
            Console.WriteLine(string.Join(", ", a.Select(x => x.ToString("F2"))));

            int maxIndex = 0;
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > a[maxIndex])
                {
                    maxIndex = i;
                }
            }

            double temp = a[a.Length - 1];
            a[a.Length - 1] = a[maxIndex];
            a[maxIndex] = temp;

            Console.WriteLine("\nМассив после замены максимального элемента с последним:");
            Console.WriteLine(string.Join(", ", a.Select(x => x.ToString("F2"))));

            Console.ReadLine();
        }
    }
}
