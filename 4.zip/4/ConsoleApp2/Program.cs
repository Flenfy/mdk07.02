﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] a = new int[10];

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = random.Next(-100, 100);
            }

            Console.WriteLine("Исходный массив:");
            Console.WriteLine(string.Join(", ", a));

            int minIndex = 0;
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] < a[minIndex])
                {
                    minIndex = i;
                }
            }
            int temp = a[0];
            a[0] = a[minIndex];
            a[minIndex] = temp;

            Console.WriteLine("\nМассив после замены первого элемента на минимальный:");
            Console.WriteLine(string.Join(", ", a));
            Console.ReadLine();
        }
    }
}
