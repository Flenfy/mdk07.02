﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Bitmap bmp;
        private Graphics g;
        private Point previousPoint;
        private Pen drawPen;
        private Color currentBrushColor = Color.Black;
        private int currentBrushSize = 5;

        public Form1()
        {
            InitializeComponent();
            drawPen = new Pen(currentBrushColor, currentBrushSize);
            radioRed.Checked = true;
        }

        private void btnBrushColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                currentBrushColor = colorDialog1.Color;
                drawPen.Color = currentBrushColor;
            }
        }

        private void numBrushSize_ValueChanged(object sender, EventArgs e)
        {
            currentBrushSize = (int)numBrushSize.Value;
            drawPen.Width = currentBrushSize;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.BMP, *.JPG, *.PNG)|*.bmp;*.jpg;*.png";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                if (bmp != null) bmp.Dispose();
                if (g != null) g.Dispose();

                Image image = Image.FromFile(dialog.FileName);
                bmp = new Bitmap(image);


                pictureBox1.Width = bmp.Width;
                pictureBox1.Height = bmp.Height;
                pictureBox1.Image = bmp;

                g = Graphics.FromImage(bmp);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Bitmap|*.bmp|JPEG|*.jpg|PNG|*.png";
            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                bmp.Save(saveDialog.FileName);
            }
        }


        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (bmp == null) return;
            previousPoint = e.Location;
        }


        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (bmp == null) return;
            if (e.Button == MouseButtons.Left)
            {
                drawPen.Color = currentBrushColor;
                drawPen.Width = currentBrushSize;

                g.DrawLine(drawPen, previousPoint, e.Location);
                previousPoint = e.Location;
                pictureBox1.Invalidate();
            }
        }


        private void btnRandomPoints_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;
            Random rand = new Random();

            for (int i = 0; i < 1000; i++)
            {
                int x = rand.Next(0, bmp.Width);
                int y = rand.Next(0, bmp.Height);
                Color randomColor = Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
                bmp.SetPixel(x, y, randomColor);
            }
            pictureBox1.Refresh();
        }

        private void btnBlackWhite_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;
            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    Color p = bmp.GetPixel(x, y);
                    int brightness = (p.R + p.G + p.B) / 3;
                    int val = (brightness > 128) ? 255 : 0;
                    bmp.SetPixel(x, y, Color.FromArgb(val, val, val));
                }
            }
            pictureBox1.Refresh();
        }


        private void btnApplyChannel_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;

            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    Color p = bmp.GetPixel(x, y);
                    int r = p.R, g = p.G, b = p.B;

                    if (radioRed.Checked)
                    {
                        bmp.SetPixel(x, y, Color.FromArgb(r, 0, 0));
                    }
                    else if (radioGreen.Checked)
                    {
                        bmp.SetPixel(x, y, Color.FromArgb(0, g, 0));
                    }
                    else if (radioBlue.Checked)
                    {
                        bmp.SetPixel(x, y, Color.FromArgb(0, 0, b));
                    }
                }
            }
            pictureBox1.Refresh();
        }


        private void btnCircleMask_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;
            int radius = (int)numRadius.Value;
            int centerX = bmp.Width / 2;
            int centerY = bmp.Height / 2;
            int radiusSq = radius * radius;

            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    int distSq = (x - centerX) * (x - centerX) + (y - centerY) * (y - centerY);

                    if (distSq > radiusSq)
                    {
                        bmp.SetPixel(x, y, Color.Black);
                    }
                }
            }
            pictureBox1.Refresh();
        }

        private void btnTriangleMask_Click(object sender, EventArgs e)
        {
            if (bmp == null) return;

            Point v1 = new Point(bmp.Width / 2, 0);
            Point v2 = new Point(0, bmp.Height);
            Point v3 = new Point(bmp.Width, bmp.Height);

            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    Point p = new Point(x, y);

                    if (!IsPointInTriangle(p, v1, v2, v3))
                    {
                        bmp.SetPixel(x, y, Color.Blue);
                    }
                }
            }
            pictureBox1.Refresh();
        }

        private bool IsPointInTriangle(Point pt, Point v1, Point v2, Point v3)
        {
            int sign(Point p1, Point p2, Point p3)
            {
                return (p1.X - p3.X) * (p2.Y - p3.Y) - (p2.X - p3.X) * (p1.Y - p3.Y);
            }

            bool b1 = sign(pt, v1, v2) < 0;
            bool b2 = sign(pt, v2, v3) < 0;
            bool b3 = sign(pt, v3, v1) < 0;

            return ((b1 == b2) && (b2 == b3));
        }
    }
}