﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.numBrushSize = new System.Windows.Forms.NumericUpDown();
            this.btnBrushColor = new System.Windows.Forms.Button();
            this.btnRandomPoints = new System.Windows.Forms.Button();
            this.btnBlackWhite = new System.Windows.Forms.Button();
            this.groupBoxChannels = new System.Windows.Forms.GroupBox();
            this.radioBlue = new System.Windows.Forms.RadioButton();
            this.radioGreen = new System.Windows.Forms.RadioButton();
            this.radioRed = new System.Windows.Forms.RadioButton();
            this.btnApplyChannel = new System.Windows.Forms.Button();
            this.numRadius = new System.Windows.Forms.NumericUpDown();
            this.btnCircleMask = new System.Windows.Forms.Button();
            this.btnTriangleMask = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.numBrushSize)).BeginInit();
            this.groupBoxChannels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // numBrushSize
            // 
            this.numBrushSize.Location = new System.Drawing.Point(794, 22);
            this.numBrushSize.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numBrushSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numBrushSize.Name = "numBrushSize";
            this.numBrushSize.Size = new System.Drawing.Size(120, 20);
            this.numBrushSize.TabIndex = 3;
            this.numBrushSize.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numBrushSize.ValueChanged += new System.EventHandler(this.numBrushSize_ValueChanged);
            // 
            // btnBrushColor
            // 
            this.btnBrushColor.Location = new System.Drawing.Point(794, 62);
            this.btnBrushColor.Name = "btnBrushColor";
            this.btnBrushColor.Size = new System.Drawing.Size(75, 23);
            this.btnBrushColor.TabIndex = 4;
            this.btnBrushColor.Text = "Цвет кисти ";
            this.btnBrushColor.UseVisualStyleBackColor = true;
            this.btnBrushColor.Click += new System.EventHandler(this.btnBrushColor_Click);
            // 
            // btnRandomPoints
            // 
            this.btnRandomPoints.Location = new System.Drawing.Point(912, 62);
            this.btnRandomPoints.Name = "btnRandomPoints";
            this.btnRandomPoints.Size = new System.Drawing.Size(75, 23);
            this.btnRandomPoints.TabIndex = 5;
            this.btnRandomPoints.Text = "1000 точек";
            this.btnRandomPoints.UseVisualStyleBackColor = true;
            this.btnRandomPoints.Click += new System.EventHandler(this.btnRandomPoints_Click);
            // 
            // btnBlackWhite
            // 
            this.btnBlackWhite.Location = new System.Drawing.Point(1025, 62);
            this.btnBlackWhite.Name = "btnBlackWhite";
            this.btnBlackWhite.Size = new System.Drawing.Size(81, 23);
            this.btnBlackWhite.TabIndex = 6;
            this.btnBlackWhite.Text = "Чёрно-белое";
            this.btnBlackWhite.UseVisualStyleBackColor = true;
            this.btnBlackWhite.Click += new System.EventHandler(this.btnBlackWhite_Click);
            // 
            // groupBoxChannels
            // 
            this.groupBoxChannels.Controls.Add(this.radioBlue);
            this.groupBoxChannels.Controls.Add(this.radioGreen);
            this.groupBoxChannels.Controls.Add(this.radioRed);
            this.groupBoxChannels.Location = new System.Drawing.Point(794, 91);
            this.groupBoxChannels.Name = "groupBoxChannels";
            this.groupBoxChannels.Size = new System.Drawing.Size(104, 89);
            this.groupBoxChannels.TabIndex = 7;
            this.groupBoxChannels.TabStop = false;
            this.groupBoxChannels.Text = "Каналы";
            // 
            // radioBlue
            // 
            this.radioBlue.AutoSize = true;
            this.radioBlue.Location = new System.Drawing.Point(7, 66);
            this.radioBlue.Name = "radioBlue";
            this.radioBlue.Size = new System.Drawing.Size(56, 17);
            this.radioBlue.TabIndex = 2;
            this.radioBlue.TabStop = true;
            this.radioBlue.Text = "Синий";
            this.radioBlue.UseVisualStyleBackColor = true;
            // 
            // radioGreen
            // 
            this.radioGreen.AutoSize = true;
            this.radioGreen.Location = new System.Drawing.Point(7, 43);
            this.radioGreen.Name = "radioGreen";
            this.radioGreen.Size = new System.Drawing.Size(70, 17);
            this.radioGreen.TabIndex = 1;
            this.radioGreen.TabStop = true;
            this.radioGreen.Text = "Зелёный";
            this.radioGreen.UseVisualStyleBackColor = true;
            // 
            // radioRed
            // 
            this.radioRed.AutoSize = true;
            this.radioRed.Location = new System.Drawing.Point(7, 20);
            this.radioRed.Name = "radioRed";
            this.radioRed.Size = new System.Drawing.Size(70, 17);
            this.radioRed.TabIndex = 0;
            this.radioRed.TabStop = true;
            this.radioRed.Text = "Красный";
            this.radioRed.UseVisualStyleBackColor = true;
            // 
            // btnApplyChannel
            // 
            this.btnApplyChannel.Location = new System.Drawing.Point(912, 105);
            this.btnApplyChannel.Name = "btnApplyChannel";
            this.btnApplyChannel.Size = new System.Drawing.Size(75, 23);
            this.btnApplyChannel.TabIndex = 8;
            this.btnApplyChannel.Text = "Применить канал";
            this.btnApplyChannel.UseVisualStyleBackColor = true;
            this.btnApplyChannel.Click += new System.EventHandler(this.btnApplyChannel_Click);
            // 
            // numRadius
            // 
            this.numRadius.Location = new System.Drawing.Point(794, 186);
            this.numRadius.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numRadius.Name = "numRadius";
            this.numRadius.Size = new System.Drawing.Size(120, 20);
            this.numRadius.TabIndex = 9;
            this.numRadius.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // btnCircleMask
            // 
            this.btnCircleMask.Location = new System.Drawing.Point(932, 183);
            this.btnCircleMask.Name = "btnCircleMask";
            this.btnCircleMask.Size = new System.Drawing.Size(75, 23);
            this.btnCircleMask.TabIndex = 10;
            this.btnCircleMask.Text = "Маска круг";
            this.btnCircleMask.UseVisualStyleBackColor = true;
            this.btnCircleMask.Click += new System.EventHandler(this.btnCircleMask_Click);
            // 
            // btnTriangleMask
            // 
            this.btnTriangleMask.Location = new System.Drawing.Point(794, 221);
            this.btnTriangleMask.Name = "btnTriangleMask";
            this.btnTriangleMask.Size = new System.Drawing.Size(120, 23);
            this.btnTriangleMask.TabIndex = 11;
            this.btnTriangleMask.Text = "Маска треугольник";
            this.btnTriangleMask.UseVisualStyleBackColor = true;
            this.btnTriangleMask.Click += new System.EventHandler(this.btnTriangleMask_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(810, 372);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Открыть";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1013, 372);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(776, 464);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 498);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnTriangleMask);
            this.Controls.Add(this.btnCircleMask);
            this.Controls.Add(this.numRadius);
            this.Controls.Add(this.btnApplyChannel);
            this.Controls.Add(this.groupBoxChannels);
            this.Controls.Add(this.btnBlackWhite);
            this.Controls.Add(this.btnRandomPoints);
            this.Controls.Add(this.btnBrushColor);
            this.Controls.Add(this.numBrushSize);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numBrushSize)).EndInit();
            this.groupBoxChannels.ResumeLayout(false);
            this.groupBoxChannels.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numBrushSize;
        private System.Windows.Forms.Button btnBrushColor;
        private System.Windows.Forms.Button btnRandomPoints;
        private System.Windows.Forms.Button btnBlackWhite;
        private System.Windows.Forms.GroupBox groupBoxChannels;
        private System.Windows.Forms.RadioButton radioBlue;
        private System.Windows.Forms.RadioButton radioGreen;
        private System.Windows.Forms.RadioButton radioRed;
        private System.Windows.Forms.Button btnApplyChannel;
        private System.Windows.Forms.NumericUpDown numRadius;
        private System.Windows.Forms.Button btnCircleMask;
        private System.Windows.Forms.Button btnTriangleMask;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

