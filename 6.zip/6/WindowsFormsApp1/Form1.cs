﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // СДВИГ ГОЛОВЫ ВВЕРХ НА 30 ПИКСЕЛЕЙ (уменьшаем координаты Y)
            int headOffsetY = -50;

            // === ГОЛОВА ===
            // Основная часть головы (эллипс) - поднята вверх
            g.FillEllipse(new SolidBrush(Color.FromArgb(245, 222, 179)), 150, 80 + headOffsetY, 180, 180);

            // Уши (2 треугольника) - подняты вверх
            Point[] leftEar = {
                new Point(150, 80 + headOffsetY),
                new Point(100, 150 + headOffsetY),
                new Point(150, 200 + headOffsetY)
            };
            g.FillPolygon(new SolidBrush(Color.FromArgb(210, 180, 140)), leftEar);

            Point[] rightEar = {
                new Point(330, 80 + headOffsetY),
                new Point(380, 150 + headOffsetY),
                new Point(330, 200 + headOffsetY)
            };
            g.FillPolygon(new SolidBrush(Color.FromArgb(210, 180, 140)), rightEar);

            // Глаза (4 круга) - подняты вверх
            g.FillEllipse(Brushes.White, 190, 120 + headOffsetY, 40, 40);
            g.FillEllipse(Brushes.White, 260, 120 + headOffsetY, 40, 40);
            g.FillEllipse(Brushes.Black, 205, 130 + headOffsetY, 15, 15);
            g.FillEllipse(Brushes.Black, 275, 130 + headOffsetY, 15, 15);

            // Нос (треугольник) - поднят вверх
            Point[] nose = {
                new Point(220, 180 + headOffsetY),
                new Point(250, 180 + headOffsetY),
                new Point(235, 210 + headOffsetY)
            };
            g.FillPolygon(new SolidBrush(Color.Brown), nose);

            // Рот (дуга) - поднят вверх
            g.DrawArc(new Pen(Color.Pink, 2), 200, 170 + headOffsetY, 60, 30, 0, 180);

            // === ТЕЛО === (немного поднято для сохранения пропорций)
            int bodyOffsetY = -15; // тело поднимаем меньше, чем голову

            // Основное тело (прямоугольник)
            g.FillRectangle(new SolidBrush(Color.FromArgb(255, 240, 220)), 200, 200 + bodyOffsetY, 200, 120);

            // Передняя часть тела (прямоугольник)
            g.FillRectangle(new SolidBrush(Color.FromArgb(250, 230, 210)), 200, 200 + bodyOffsetY, 100, 120);

            // Задняя часть тела (прямоугольник)
            g.FillRectangle(new SolidBrush(Color.FromArgb(255, 220, 190)), 300, 200 + bodyOffsetY, 100, 120);

            // Брюхо (прямоугольник)
            g.FillRectangle(new SolidBrush(Color.FromArgb(255, 250, 240)), 220, 250 + bodyOffsetY, 160, 50);

            // === ЛАПЫ === (подняты вместе с телом)
            g.FillPolygon(new SolidBrush(Color.FromArgb(200, 150, 100)),
                new Point[] {
                    new Point(220, 320 + bodyOffsetY),
                    new Point(200, 340 + bodyOffsetY),
                    new Point(220, 360 + bodyOffsetY),
                    new Point(240, 340 + bodyOffsetY)
                });

            g.FillPolygon(new SolidBrush(Color.FromArgb(220, 170, 120)),
                new Point[] {
                    new Point(280, 320 + bodyOffsetY),
                    new Point(260, 340 + bodyOffsetY),
                    new Point(280, 360 + bodyOffsetY),
                    new Point(300, 340 + bodyOffsetY)
                });

            g.FillPolygon(new SolidBrush(Color.FromArgb(200, 150, 100)),
                new Point[] {
                    new Point(350, 320 + bodyOffsetY),
                    new Point(330, 340 + bodyOffsetY),
                    new Point(350, 360 + bodyOffsetY),
                    new Point(370, 340 + bodyOffsetY)
                });

            g.FillPolygon(new SolidBrush(Color.FromArgb(220, 170, 120)),
                new Point[] {
                    new Point(410, 320 + bodyOffsetY),
                    new Point(390, 340 + bodyOffsetY),
                    new Point(410, 360 + bodyOffsetY),
                    new Point(430, 340 + bodyOffsetY)
                });

            // === ХВОСТ === (поднят вместе с телом)
            g.FillEllipse(new SolidBrush(Color.FromArgb(255, 200, 200)), 450, 190 + bodyOffsetY, 20, 20);
            g.FillEllipse(new SolidBrush(Color.FromArgb(255, 220, 220)), 470, 170 + bodyOffsetY, 20, 20);
            g.FillEllipse(new SolidBrush(Color.FromArgb(255, 240, 220)), 490, 150 + bodyOffsetY, 20, 20);
            g.FillEllipse(new SolidBrush(Color.FromArgb(230, 200, 180)), 510, 130 + bodyOffsetY, 20, 20);
            g.FillEllipse(new SolidBrush(Color.FromArgb(210, 180, 160)), 530, 110 + bodyOffsetY, 20, 20);
        }
    }
}
