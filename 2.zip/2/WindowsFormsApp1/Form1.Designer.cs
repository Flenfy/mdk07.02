﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.ellips = new System.Windows.Forms.Button();
            this.param = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ellips
            // 
            this.ellips.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F);
            this.ellips.Location = new System.Drawing.Point(250, 240);
            this.ellips.Name = "ellips";
            this.ellips.Size = new System.Drawing.Size(250, 47);
            this.ellips.TabIndex = 0;
            this.ellips.Text = "Эллипс";
            this.ellips.UseVisualStyleBackColor = true;
            this.ellips.Click += new System.EventHandler(this.ellips_Click);
            // 
            // param
            // 
            this.param.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F);
            this.param.Location = new System.Drawing.Point(250, 142);
            this.param.Name = "param";
            this.param.Size = new System.Drawing.Size(250, 52);
            this.param.TabIndex = 1;
            this.param.Text = "Параллелограм";
            this.param.UseVisualStyleBackColor = true;
            this.param.Click += new System.EventHandler(this.param_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(253, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Выберите фигуру";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.param);
            this.Controls.Add(this.ellips);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ellips;
        private System.Windows.Forms.Button param;
        private System.Windows.Forms.Label label1;
    }
}

