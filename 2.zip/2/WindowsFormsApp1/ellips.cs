﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ellips : Form
    {
        double a, b;
        string sqrt, perim;
        public ellips()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            string sqrt = Convert.ToString(Math.PI * a * b);
            string perim = Convert.ToString(2 * Math.PI * Math.Sqrt(0.5 * (Math.Pow(a, 2) + Math.Pow(b, 2))));
            MessageBox.Show("Площадь элипса равна " + sqrt + ", а периметр равен " + perim);
        }
    }
}
