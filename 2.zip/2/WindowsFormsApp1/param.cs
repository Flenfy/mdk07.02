﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class param : Form
    {
        public param()
        {
            InitializeComponent();
        }

        double a, b, h;
        string sqrt, perim;


        private void button1_Click(object sender, EventArgs e)
        {
            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            h = double.Parse(textBox3.Text);

            sqrt = Convert.ToString(a * h);
            perim = Convert.ToString(2 * (a + b));
            MessageBox.Show("Площадь параллелограма равен " + sqrt + ", а периметр равен " + perim);
        }
    }
}
