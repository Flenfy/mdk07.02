﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите какую фигуру хотите вычислить параллелограм или эллипс");
            string result = Console.ReadLine();
            if (result == "эллипс")
            {
                Console.WriteLine("Введите сторону a эллипса");
                int a = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите сторону b эллипса");
                int b = int.Parse(Console.ReadLine());

                var ellips = Ellips(a, b);
                Console.WriteLine("Площадь эллипса: " + ellips.sqrt);
                Console.WriteLine("Периметр эллипса: " + ellips.perim);
                Console.ReadLine();
            }
            else if (result == "параллелограм")
            {
                Console.WriteLine("Введите сторону a для параллелограма");
                double a = double.Parse(Console.ReadLine());
                Console.WriteLine("Введите сторону b для параллелограма");
                double b = double.Parse(Console.ReadLine());
                Console.WriteLine("Введите высоту h для парраллограма");
                double h = double.Parse(Console.ReadLine());

                var param = Param(a, b, h);
                Console.WriteLine("Площадь параллелограма: " + param.sqrt);
                Console.WriteLine("Периметр параллелограма: " + param.perim);
                Console.ReadLine();
            }
        }

        private static (string sqrt, string perim) Param(double a, double b, double h)
        {
            string sqrt = Convert.ToString(a * h);
            string perim = Convert.ToString(2 * (a + b));
            return (sqrt, perim);
        }

        private static (string sqrt, string perim) Ellips(int a, int b)
        {
            string sqrt = Convert.ToString(Math.PI * a * b);
            string perim = Convert.ToString(2 * Math.PI * Math.Sqrt(0.5 * (Math.Pow(a, 2) + Math.Pow(b, 2))));
            return (sqrt, perim);
        }
    }
}
